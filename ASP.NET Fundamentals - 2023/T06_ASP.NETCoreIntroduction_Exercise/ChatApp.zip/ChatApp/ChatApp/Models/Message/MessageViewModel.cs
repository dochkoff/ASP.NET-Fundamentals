﻿namespace ChatApp.Models.Message
{
    public class MessageViewModel
    {
        public string Sender { get; set; } = string.Empty;
        public string MessageText { get; set; } = string.Empty;
    }
}
